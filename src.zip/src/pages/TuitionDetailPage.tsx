import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  ArrowLeft,
  MapPin,
  Calendar,
  User,
  MessageCircle,
  Heart,
  Share2,
  Flag,
  Trash2,
  MoreVertical,
  AlertTriangle,
  DollarSign,
  Clock,
  GraduationCap,
  Phone,
  Building,
  ExternalLink,
  UserCheck,
} from "lucide-react";
import { useAuth } from "../hooks/useAuth";
import { tuitionAPI, wishlistAPI, messageAPI } from "../services/apiService";

export function TuitionDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [message, setMessage] = useState("");
  const [showOptionsMenu, setShowOptionsMenu] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [tuition, setTuition] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [wishlistNote, setWishlistNote] = useState("");
  const [showWishlistModal, setShowWishlistModal] = useState(false);

  useEffect(() => {
    const fetchTuition = async () => {
      if (!id || !user) return;
      
      try {
        setLoading(true);
        const tuitionData = await tuitionAPI.getTuitionById(parseInt(id));
        setTuition(tuitionData);
        
        // Check wishlist status
        try {
          const wishlistStatus = await wishlistAPI.checkWishlistStatus(Number(user.id), tuitionData.tuitionId);
          setIsWishlisted(wishlistStatus.isWishlisted);
          if (wishlistStatus.notes) {
            setWishlistNote(wishlistStatus.notes);
          }
        } catch (wishlistError) {
          // Wishlist check failed, assume not wishlisted
          setIsWishlisted(false);
        }
      } catch (err) {
        setError('Failed to load tuition details');
        console.error('Error fetching tuition:', err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchTuition();
  }, [id, user]);

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Sign In Required
          </h2>
          <p className="text-gray-600 mb-6">
            You need to be signed in to view tuition details.
          </p>
          <button
            onClick={() => navigate("/login")}
            className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading tuition details...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Error</h2>
          <p className="text-gray-600 mb-6">{error}</p>
          <button
            onClick={() => navigate("/browse/tuitions")}
            className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors"
          >
            Back to Browse Tuitions
          </button>
        </div>
      </div>
    );
  }

  if (!tuition) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Tuition Not Found
          </h2>
          <p className="text-gray-600 mb-6">
            The tuition you're looking for doesn't exist.
          </p>
          <button
            onClick={() => navigate("/browse/tuitions")}
            className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors"
          >
            Back to Browse Tuitions
          </button>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 text-green-800";
      case "taken":
        return "bg-orange-100 text-orange-800";
      case "completed":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const handleSendMessage = async () => {
    if (!user || !tuition) {
      navigate("/login");
      return;
    }
    
    try {
      await messageAPI.sendMessage({
        senderId: Number(user.id),
        receiverId: tuition.post?.user?.userId || 0,
        text: message
      });
      
      setShowMessageModal(false);
      setMessage("");
      alert("Message sent successfully!");
    } catch (error) {
      console.error('Error sending message:', error);
      alert("Failed to send message. Please try again.");
    }
  };

  const handleWishlist = async () => {
    if (!user || !tuition) return;
    
    try {
      if (isWishlisted) {
        await wishlistAPI.removeFromWishlist(Number(user.id), tuition.tuitionId);
        setIsWishlisted(false);
        setWishlistNote("");
      } else {
        setWishlistNote("");
        setShowWishlistModal(true);
      }
    } catch (error) {
      console.error('Error updating wishlist:', error);
      alert("Failed to update wishlist. Please try again.");
    }
  };

  const handleSaveWishlist = async () => {
    if (!user || !tuition) return;
    
    try {
      await wishlistAPI.addToWishlist(Number(user.id), tuition.tuitionId, wishlistNote);
      setIsWishlisted(true);
      setShowWishlistModal(false);
    } catch (error) {
      console.error('Error saving to wishlist:', error);
      alert("Failed to save to wishlist. Please try again.");
    }
  };

  const isOwnTuition = user?.id === tuition?.post?.user?.userId;

  const handleDeleteTuition = async () => {
    if (!tuition) return;
    
    try {
      await tuitionAPI.deleteTuition(tuition.tuitionId);
      navigate("/browse/tuitions");
    } catch (error) {
      console.error('Error deleting tuition:', error);
      alert("Failed to delete tuition. Please try again.");
    }
  };

  const handleReportTuition = () => {
    console.log("Reporting tuition:", tuition.id, "Reason:", reportReason);
    setShowReportModal(false);
    setReportReason("");
    alert("Report submitted successfully!");
  };

  const handleReportUser = () => {
    console.log("Reporting user:", tuition.tutor_id);
    alert("User report submitted successfully!");
  };

  return (
    <div className="min-h-screen bg-green-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back</span>
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-8">
              <div className="flex items-start justify-between mb-6">
                <h1 className="text-3xl font-bold text-gray-900">
                  {tuition.subject} Tuition
                </h1>
                <span
                  className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(
                    tuition.tStatus
                  )}`}
                >
                  {tuition.tStatus?.charAt(0).toUpperCase() +
                    tuition.tStatus?.slice(1)}
                </span>
              </div>

              <div className="mb-6">
                <h3 className="font-semibold text-gray-900 mb-3">Subject</h3>
                <div className="flex flex-wrap gap-2">
                  <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                    {tuition.subject}
                  </span>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="bg-green-50 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <DollarSign className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Salary</h4>
                      <p className="text-2xl font-bold text-green-600">
                        ৳{tuition.salary || 0}
                      </p>
                      <p className="text-sm text-gray-600">per month</p>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <Calendar className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Schedule</h4>
                      <p className="text-2xl font-bold text-blue-600">
                        {tuition.daysWeek || 0}
                      </p>
                      <p className="text-sm text-gray-600">days per week</p>
                    </div>
                  </div>
                </div>

                <div className="bg-purple-50 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                      <GraduationCap className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">
                        Class Level
                      </h4>
                      <p className="text-lg font-bold text-purple-600">
                        {tuition.clazz || 'Not specified'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-orange-50 rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                      <MapPin className="h-5 w-5 text-orange-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Location</h4>
                      <p className="text-lg font-bold text-orange-600">
                        {tuition.location?.locationName || 'Location not specified'}
                      </p>
                      <p className="text-sm text-gray-600 capitalize">
                        {tuition.location?.locationType?.replace("-", " ") || ''}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Additional Information */}
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                {tuition.department && (
                  <div className="bg-indigo-50 rounded-xl p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                        <Building className="h-5 w-5 text-indigo-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Department</h4>
                        <p className="text-lg font-bold text-indigo-600">
                          {tuition.department}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {tuition.phone && (
                  <div className="bg-teal-50 rounded-xl p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-teal-100 rounded-full flex items-center justify-center">
                        <Phone className="h-5 w-5 text-teal-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Phone</h4>
                        <p className="text-lg font-bold text-teal-600">
                          {tuition.phone}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {tuition.preferred_tutor && (
                  <div className="bg-pink-50 rounded-xl p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center">
                        <UserCheck className="h-5 w-5 text-pink-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Preferred Tutor</h4>
                        <p className="text-lg font-bold text-pink-600 capitalize">
                          {tuition.preferred_tutor}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {tuition.address_url && (
                  <div className="bg-amber-50 rounded-xl p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                        <ExternalLink className="h-5 w-5 text-amber-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Address</h4>
                        <a
                          href={tuition.address_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-lg font-bold text-amber-600 hover:text-amber-700 underline"
                        >
                          View Location
                        </a>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <Clock className="h-4 w-4" />
                <span>Posted on {formatDate(tuition.post?.postTime || new Date().toISOString())}</span>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Posted by</h3>

              <div className="flex items-center space-x-4 mb-4">
                {tuition.post?.user?.profilePicture ? (
                  <img
                    src={tuition.post.user.profilePicture}
                    alt={tuition.post.user.username}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-blue-600 rounded-full flex items-center justify-center">
                    <span className="text-white font-semibold">
                      {tuition.post?.user?.username?.charAt(0).toUpperCase() || 'U'}
                    </span>
                  </div>
                )}
                <div>
                  <Link
                    to={`/profile/${tuition.post?.user?.userId}`}
                    className="font-semibold text-gray-900 hover:text-green-600 transition-colors"
                  >
                    {tuition.post?.user?.username || 'Unknown User'}
                  </Link>
                  <p className="text-sm text-gray-600">Posted this tuition</p>
                </div>
              </div>

              {tuition.post?.user?.bio && (
                <p className="text-gray-600 text-sm mb-4">
                  {tuition.post.user.bio}
                </p>
              )}
            </div>

            <div className="bg-white rounded-xl shadow-sm p-6 space-y-4">
              {!isOwnTuition && (
                <button
                  onClick={() => setShowMessageModal(true)}
                  className="w-full bg-green-600 text-white py-3 rounded-xl font-semibold hover:bg-green-700 transition-colors flex items-center justify-center space-x-2"
                >
                  <MessageCircle className="h-5 w-5" />
                  <span>Contact Tutor</span>
                </button>
              )}

              <div className="flex space-x-3">
                <button
                  className={`flex-1 ${
                    isWishlisted
                      ? "bg-green-100 text-green-700"
                      : "bg-gray-100 text-gray-700"
                  } py-3 rounded-xl font-medium hover:bg-gray-200 transition-colors flex items-center justify-center space-x-2`}
                  onClick={handleWishlist}
                >
                  <Heart
                    className="h-5 w-5"
                    fill={isWishlisted ? "#22c55e" : "none"}
                  />
                  <span>{isWishlisted ? "Saved" : "Save"}</span>
                </button>

                <button
                  onClick={() => {
                    const link = window.location.href;
                    navigator.clipboard
                      .writeText(link)
                      .then(() => alert("Link Copied"))
                      .catch(() => alert("Failed to copy link"));
                  }}
                  className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium hover:bg-gray-200 transition-colors flex items-center justify-center space-x-2"
                >
                  <Share2 className="h-5 w-5" />
                  <span>Share</span>
                </button>

                <div className="relative">
                  <button
                    onClick={() => setShowOptionsMenu(!showOptionsMenu)}
                    className="px-4 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium hover:bg-gray-200 transition-colors"
                  >
                    <MoreVertical className="h-5 w-5" />
                  </button>

                  {showOptionsMenu && (
                    <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-10">
                      {isOwnTuition ? (
                        <button
                          onClick={() => {
                            setShowDeleteModal(true);
                            setShowOptionsMenu(false);
                          }}
                          className="w-full px-4 py-3 text-left text-red-600 hover:bg-red-50 flex items-center space-x-2 rounded-t-lg"
                        >
                          <Trash2 className="h-4 w-4" />
                          <span>Delete Tuition</span>
                        </button>
                      ) : (
                        <>
                          <button
                            onClick={() => {
                              setShowReportModal(true);
                              setShowOptionsMenu(false);
                            }}
                            className="w-full px-4 py-3 text-left text-red-600 hover:bg-red-50 flex items-center space-x-2 rounded-t-lg"
                          >
                            <Flag className="h-4 w-4" />
                            <span>Report Tuition</span>
                          </button>
                          <button
                            onClick={() => {
                              handleReportUser();
                              setShowOptionsMenu(false);
                            }}
                            className="w-full px-4 py-3 text-left text-red-600 hover:bg-red-50 flex items-center space-x-2 rounded-b-lg border-t border-gray-100"
                          >
                            <AlertTriangle className="h-4 w-4" />
                            <span>Report User</span>
                          </button>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {isWishlisted && wishlistNote && (
                <div className="bg-green-50 border-l-4 border-green-400 p-4 rounded">
                  <div className="text-green-800 font-semibold mb-1">
                    Your Note:
                  </div>
                  <div className="text-green-900">{wishlistNote}</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Message Modal */}
      {showMessageModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Send Message to {tuition.post?.user?.username || 'Tutor'}
            </h3>

            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Hi! I'm interested in your tuition offer..."
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
              rows={4}
            />

            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => setShowMessageModal(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSendMessage}
                disabled={!message.trim()}
                className="flex-1 bg-green-600 text-white py-3 rounded-lg font-medium hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Send Message
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <Trash2 className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">
                  Delete Tuition
                </h3>
                <p className="text-gray-600">This action cannot be undone</p>
              </div>
            </div>

            <p className="text-gray-700 mb-6">
              Are you sure you want to delete this "{tuition.subject}" tuition? This will
              permanently remove the tuition offer and all associated data.
            </p>

            <div className="flex space-x-4">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteTuition}
                className="flex-1 bg-red-600 text-white py-3 rounded-lg font-medium hover:bg-red-700 transition-colors"
              >
                Delete Tuition
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <Flag className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">
                  Report Tuition
                </h3>
                <p className="text-gray-600">Help us keep the community safe</p>
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reason for reporting
              </label>
              <select
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500"
              >
                <option value="">Select a reason</option>
                <option value="inappropriate">Inappropriate content</option>
                <option value="spam">Spam or misleading</option>
                <option value="fake">Fake or fraudulent</option>
                <option value="harassment">Harassment</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => setShowReportModal(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleReportTuition}
                disabled={!reportReason}
                className="flex-1 bg-red-600 text-white py-3 rounded-lg font-medium hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Submit Report
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Wishlist Modal */}
      {showWishlistModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Add Note to Saved Tuitions
            </h3>
            <textarea
              value={wishlistNote}
              onChange={(e) => setWishlistNote(e.target.value)}
              placeholder="Add a note about this tuition..."
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
              rows={4}
            />
            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => setShowWishlistModal(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveWishlist}
                className="flex-1 bg-green-600 text-white py-3 rounded-lg font-medium hover:bg-green-700 transition-colors"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
