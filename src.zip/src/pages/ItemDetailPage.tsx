import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  ArrowLeft,
  MapPin,
  Calendar,
  User,
  MessageCircle,
  Heart,
  Share2,
  Flag,
  Trash2,
  MoreVertical,
  AlertTriangle,
  Phone,
} from "lucide-react";
import { Item } from "../types";
import { useAuth } from "../hooks/useAuth";
import { itemAPI, wishlistAPI, messageAPI } from "../services/apiService";
import { UserStorage } from "../utils/userStorage";

export function ItemDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [item, setItem] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [message, setMessage] = useState("");
  const [showOptionsMenu, setShowOptionsMenu] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [showWishlistModal, setShowWishlistModal] = useState(false);
  const [wishlistNote, setWishlistNote] = useState("");
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [newStatus, setNewStatus] = useState("");
  const [statusNote, setStatusNote] = useState("");
  const wishlist = UserStorage.getWishlist();

  // Fetch item from API
  useEffect(() => {
    const fetchItem = async () => {
      if (!id) return;

      try {
        setLoading(true);
        const fetchedItem = await itemAPI.getItemById(parseInt(id));
        setItem(fetchedItem);

        // Check if item is wishlisted
        if (user) {
          try {
            const wishlistItems = await wishlistAPI.getUserWishlists(
              parseInt(user.id)
            );
            const isInWishlist = wishlistItems.some(
              (w: any) =>
                Array.isArray(w.items) &&
                w.items.some((it: any) => it.itemId === fetchedItem.itemId)
            );
            setIsWishlisted(isInWishlist);
          } catch (err) {
            console.error("Error checking wishlist:", err);
          }
        }
      } catch (err) {
        setError("Failed to load item");
        console.error("Error fetching item:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchItem();
  }, [id, user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading item...</p>
        </div>
      </div>
    );
  }

  if (error || !item) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Item Not Found
          </h2>
          <p className="text-gray-600 mb-6">
            {error || "The item you're looking for doesn't exist."}
          </p>
          <button
            onClick={() => navigate("/browse")}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Browse
          </button>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Sign In Required
          </h2>
          <p className="text-gray-600 mb-6">
            You need to be signed in to view item details.
          </p>
          <button
            onClick={() => navigate("/login")}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  const getTypeColor = (type: string) => {
    switch (type?.toLowerCase()) {
      case "free":
        return "bg-green-100 text-green-800";
      case "swap":
        return "bg-blue-100 text-blue-800";
      case "rent":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case "New":
        return "bg-emerald-100 text-emerald-800";
      case "Like New":
        return "bg-blue-100 text-blue-800";
      case "Good":
        return "bg-yellow-100 text-yellow-800";
      case "Fair":
        return "bg-orange-100 text-orange-800";
      case "Poor":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const handleSendMessage = async () => {
    if (!user || !item) {
      navigate("/login");
      return;
    }

    try {
      await messageAPI.sendMessage({
        senderId: parseInt(user.id),
        receiverId: parseInt(item.post?.user?.userId || item.user?.id || "0"),
        text: message,
        itemId: item.itemId,
      });

      setShowMessageModal(false);
      setMessage("");
      alert("Message sent successfully!");
    } catch (error) {
      console.error("Error sending message:", error);
      alert("Failed to send message");
    }
  };

  const handleWishlist = async () => {
    if (!user || !item) return;

    try {
      if (isWishlisted) {
        await wishlistAPI.removeFromWishlist(parseInt(user.id), item.itemId!);
        setIsWishlisted(false);
      } else {
        setWishlistNote("");
        setShowWishlistModal(true);
      }
    } catch (error) {
      console.error("Error updating wishlist:", error);
      alert("Failed to update wishlist");
    }
  };

  const handleSaveWishlist = async () => {
    if (!user || !item) return;

    try {
      await wishlistAPI.addToWishlist(
        parseInt(user.id),
        item.itemId!,
        wishlistNote
      );
      setIsWishlisted(true);
      setShowWishlistModal(false);
      setWishlistNote("");
    } catch (error) {
      console.error("Error adding to wishlist:", error);
      alert("Failed to add to wishlist");
    }
  };

  const isOwnItem =
    Number(user?.id) ===
    Number(item.post?.user?.userId || item.user?.id || item.post?.user?.id);

  const handleDeleteItem = async () => {
    if (!item?.itemId) return;

    try {
      await itemAPI.deleteItem(item.itemId);
      navigate("/browse");
    } catch (error) {
      console.error("Error deleting item:", error);
      alert("Failed to delete item");
    }
  };

  const handleReportItem = () => {
    // In a real app, this would send report to backend
    console.log("Reporting item:", item.id, "Reason:", reportReason);
    setShowReportModal(false);
    setReportReason("");
    alert("Report submitted successfully!");
  };

  const handleReportUser = () => {
    // In a real app, this would send user report to backend
    console.log("Reporting user:", item.user_id);
    alert("User report submitted successfully!");
  };

  const handleStatusUpdate = () => {
    if (!newStatus || !statusNote.trim()) return;

    try {
      // Update item status
      const items = UserStorage.getItems();
      const itemIndex = items.findIndex((i: any) => i.id === item.id);

      if (itemIndex !== -1) {
        items[itemIndex].status = newStatus;
        items[itemIndex].status_updated_at = new Date().toISOString();
        UserStorage.setItems(items);

        // Add to status history
        const existingHistory = UserStorage.getItemStatusHistory(item.id);
        const newHistoryEntry = {
          id: `history-${Date.now()}`,
          status: newStatus,
          note: statusNote,
          updated_at: new Date().toISOString(),
          updated_by: user?.username || "Unknown",
        };
        existingHistory.push(newHistoryEntry);
        UserStorage.setItemStatusHistory(item.id, existingHistory);

        setShowStatusModal(false);
        setNewStatus("");
        setStatusNote("");

        // Refresh the page to show updated status
        window.location.reload();
      }
    } catch (error) {
      console.error("Error updating status:", error);
      alert("Failed to update status");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back</span>
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Images */}
          <div className="space-y-4">
            <div className="aspect-w-16 aspect-h-12 bg-gray-200 rounded-xl overflow-hidden">
              {item.images && item.images.length > 0 ? (
                <img
                  src={item.images[currentImageIndex]}
                  alt={item.itemName || item.title}
                  className="w-full h-96 object-cover"
                />
              ) : (
                <div className="w-full h-96 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                  <div className="text-center">
                    <div className="h-16 w-16 bg-gray-300 rounded-full mx-auto mb-4"></div>
                    <p className="text-gray-500">No image available</p>
                  </div>
                </div>
              )}
            </div>

            {item.images && item.images.length > 1 && (
              <div className="flex space-x-2 overflow-x-auto">
                {item.images.map((image: string, index: number) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                      currentImageIndex === index
                        ? "border-blue-500"
                        : "border-gray-200"
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${item.itemName || item.title} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Item Details */}
          <div className="space-y-6">
            <div>
              <div className="flex items-start justify-between mb-4">
                <h1 className="text-3xl font-bold text-gray-900">
                  {item.itemName || item.title}
                </h1>
                <span
                  className={`px-3 py-1 rounded-full text-sm font-medium ${getTypeColor(
                    item.itemType || item.type || "unknown"
                  )}`}
                >
                  {(item.itemType || item.type || "unknown")
                    .charAt(0)
                    .toUpperCase() +
                    (item.itemType || item.type || "unknown").slice(1)}
                </span>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                  {item.category?.categoryName ||
                    item.category?.name ||
                    "Uncategorized"}
                </span>
                <span
                  className={`px-3 py-1 rounded-full text-sm font-medium ${getConditionColor(
                    item.itemCondition || item.condition || "Unknown"
                  )}`}
                >
                  {item.itemCondition || item.condition || "Unknown"}
                </span>
                {item.department && (
                  <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm">
                    {item.department}
                  </span>
                )}
              </div>
            </div>

            <div className="prose max-w-none">
              <p className="text-gray-700 text-lg leading-relaxed">
                {item.description}
              </p>
            </div>

            {/* Item Info */}
            <div className="bg-gray-50 rounded-xl p-6 space-y-4 mb-6">
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-gray-400" />
                <div>
                  <span className="text-gray-700 font-medium">
                    {item.location?.locationType === "ON_CAMPUS" ||
                    item.location?.type === "on-campus"
                      ? "On Campus"
                      : "Off Campus"}
                  </span>
                  <span className="text-gray-500 mx-2">•</span>
                  <span className="text-gray-700">
                    {item.location?.locationName ||
                      item.location?.name ||
                      "Unknown location"}
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Calendar className="h-5 w-5 text-gray-400" />
                <span className="text-gray-700">
                  Posted on{" "}
                  {formatDate(
                    item.post?.postTime ||
                      item.created_at ||
                      new Date().toISOString()
                  )}
                </span>
              </div>

              <div className="flex items-center space-x-3">
                <User className="h-5 w-5 text-gray-400" />
                <Link
                  to={`/profile/${item.post?.user?.userId || item.user?.id}`}
                  className="text-blue-600 hover:text-blue-700 font-medium"
                >
                  {item.post?.user?.username ||
                    item.user?.username ||
                    "Anonymous"}
                </Link>
              </div>

              {item.department && (
                <div className="flex items-center space-x-3">
                  <div className="h-5 w-5 bg-purple-100 rounded-full flex items-center justify-center">
                    <div className="h-2 w-2 bg-purple-600 rounded-full"></div>
                  </div>
                  <span className="text-gray-700">
                    Department: {item.department}
                  </span>
                </div>
              )}

              {item.phone && (
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-gray-400" />
                  <span className="text-gray-700">Phone: {item.phone}</span>
                </div>
              )}
            </div>

            {/* Additional Details */}
            <div className="bg-blue-50 rounded-xl p-6 space-y-3 mb-6">
              <h3 className="font-semibold text-gray-900 mb-3">Item Details</h3>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                <span className="text-gray-700">
                  <span className="font-medium">Category:</span>{" "}
                  {item.category?.categoryName ||
                    item.category?.name ||
                    "Uncategorized"}
                </span>
              </div>

              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                <span className="text-gray-700">
                  <span className="font-medium">Condition:</span>{" "}
                  {item.itemCondition || item.condition || "Unknown"}
                </span>
              </div>

              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                <span className="text-gray-700">
                  <span className="font-medium">Type:</span>{" "}
                  {(item.itemType || item.type || "unknown")
                    .charAt(0)
                    .toUpperCase() +
                    (item.itemType || item.type || "unknown").slice(1)}
                </span>
              </div>

              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                <span className="text-gray-700">
                  <span className="font-medium">Price:</span>{" "}
                  {item.price || "Not specified"}
                </span>
              </div>
            </div>

            {/* Status Update (Owner Only) */}
            {isOwnItem &&
              item.status !== "donated" &&
              item.status !== "exchanged" &&
              item.status !== "rented" && (
                <div className="bg-yellow-50 rounded-xl p-6 mb-6">
                  <h3 className="font-semibold text-gray-900 mb-3">
                    Update Item Status
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Mark this item as donated, exchanged, or rented when
                    completed.
                  </p>
                  <button
                    onClick={() => setShowStatusModal(true)}
                    className="bg-yellow-600 text-white px-6 py-3 rounded-lg hover:bg-yellow-700 transition-colors"
                  >
                    Update Status
                  </button>
                </div>
              )}

            {/* Status History */}
            {(() => {
              const history = UserStorage.getItemStatusHistory(item.id);
              return history.length > 0 ? (
                <div className="bg-gray-50 rounded-xl p-6 mb-6">
                  <h3 className="font-semibold text-gray-900 mb-3">
                    Status History
                  </h3>
                  <div className="space-y-3">
                    {history.reverse().map((entry: any) => (
                      <div
                        key={entry.id}
                        className="bg-white rounded-lg p-4 border border-gray-200"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-gray-900 capitalize">
                            {entry.status}
                          </span>
                          <span className="text-sm text-gray-500">
                            {new Date(entry.updated_at).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-gray-600 text-sm">{entry.note}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          Updated by {entry.updated_by}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              ) : null;
            })()}

            {/* Actions */}
            <div className="space-y-4">
              {!isOwnItem && (
                <button
                  onClick={() => setShowMessageModal(true)}
                  className="w-full bg-pine-green text-white py-4 rounded-xl font-semibold hover:bg-dark-teal transition-colors flex items-center justify-center space-x-2"
                >
                  <MessageCircle className="h-5 w-5" />
                  <span>
                    Contact{" "}
                    {item.post?.user?.username || item.user?.username || "User"}
                  </span>
                </button>
              )}

              <div className="flex space-x-4">
                <button
                  className={`flex-1 ${
                    isWishlisted
                      ? "bg-green-100 text-green-700"
                      : "bg-gray-100 text-gray-700"
                  } py-3 rounded-xl font-medium hover:bg-gray-200 transition-colors flex items-center justify-center space-x-2`}
                  onClick={handleWishlist}
                >
                  <Heart
                    className="h-5 w-5"
                    fill={isWishlisted ? "#22c55e" : "none"}
                  />
                  <span>{isWishlisted ? "Wishlisted" : "Add to Wishlist"}</span>
                </button>

                <button
                  onClick={() => {
                    const link = window.location.href;
                    navigator.clipboard
                      .writeText(link)
                      .then(() => alert("Link Copied"))
                      .catch(() => alert("Failed to copy link"));
                  }}
                  className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium hover:bg-gray-200 transition-colors flex items-center justify-center space-x-2"
                >
                  <Share2 className="h-5 w-5" />
                  <span>Share</span>
                </button>

                <div className="relative">
                  <button
                    onClick={() => setShowOptionsMenu(!showOptionsMenu)}
                    className="px-4 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium hover:bg-gray-200 transition-colors"
                  >
                    <MoreVertical className="h-5 w-5" />
                  </button>

                  {showOptionsMenu && (
                    <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-10">
                      {isOwnItem ? (
                        <button
                          onClick={() => {
                            setShowDeleteModal(true);
                            setShowOptionsMenu(false);
                          }}
                          className="w-full px-4 py-3 text-left text-red-600 hover:bg-red-50 flex items-center space-x-2 rounded-t-lg"
                        >
                          <Trash2 className="h-4 w-4" />
                          <span>Delete Post</span>
                        </button>
                      ) : (
                        <>
                          <button
                            onClick={() => {
                              setShowReportModal(true);
                              setShowOptionsMenu(false);
                            }}
                            className="w-full px-4 py-3 text-left text-red-600 hover:bg-red-50 flex items-center space-x-2 rounded-t-lg"
                          >
                            <Flag className="h-4 w-4" />
                            <span>Report Post</span>
                          </button>
                          <button
                            onClick={() => {
                              handleReportUser();
                              setShowOptionsMenu(false);
                            }}
                            className="w-full px-4 py-3 text-left text-red-600 hover:bg-red-50 flex items-center space-x-2 rounded-b-lg border-t border-gray-100"
                          >
                            <AlertTriangle className="h-4 w-4" />
                            <span>Report User</span>
                          </button>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {isWishlisted && wishlist[item.id] && (
              <div className="bg-green-50 border-l-4 border-green-400 p-4 rounded mb-4">
                <div className="text-green-800 font-semibold mb-1">
                  Your Wishlist Note:
                </div>
                <div className="text-green-900">{wishlist[item.id]?.note}</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Message Modal */}
      {showMessageModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Send Message to{" "}
              {item.post?.user?.username || item.user?.username || "User"}
            </h3>

            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Hi! I'm interested in your item..."
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              rows={4}
            />

            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => setShowMessageModal(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSendMessage}
                disabled={!message.trim()}
                className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Send Message
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <Trash2 className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">Delete Post</h3>
                <p className="text-gray-600">This action cannot be undone</p>
              </div>
            </div>

            <p className="text-gray-700 mb-6">
              Are you sure you want to delete "{item.itemName || item.title}"?
              This will permanently remove the post and all associated data.
            </p>

            <div className="flex space-x-4">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteItem}
                className="flex-1 bg-red-600 text-white py-3 rounded-lg font-medium hover:bg-red-700 transition-colors"
              >
                Delete Post
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <Flag className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">Report Post</h3>
                <p className="text-gray-600">Help us keep the community safe</p>
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reason for reporting
              </label>
              <select
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500"
                required
              >
                <option value="">Select a reason</option>
                <option value="inappropriate">Inappropriate content</option>
                <option value="spam">Spam or misleading</option>
                <option value="fake">Fake or fraudulent</option>
                <option value="harassment">Harassment</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => setShowReportModal(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleReportItem}
                disabled={!reportReason}
                className="flex-1 bg-red-600 text-white py-3 rounded-lg font-medium hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Submit Report
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Wishlist Modal */}
      {showWishlistModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Add Note to Wishlist
            </h3>
            <textarea
              value={wishlistNote}
              onChange={(e) => setWishlistNote(e.target.value)}
              placeholder="Add a note about this item..."
              className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              rows={4}
            />
            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => setShowWishlistModal(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveWishlist}
                className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Status Update Modal */}
      {showStatusModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Update Item Status
            </h3>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                New Status
              </label>
              <select
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-yellow-500"
              >
                <option value="">Select status</option>
                <option value="donated">Donated</option>
                <option value="exchanged">Exchanged</option>
                <option value="rented">Rented</option>
              </select>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Note (required)
              </label>
              <textarea
                value={statusNote}
                onChange={(e) => setStatusNote(e.target.value)}
                placeholder="Add details about the transaction..."
                className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-yellow-500 focus:border-transparent resize-none"
                rows={3}
              />
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => setShowStatusModal(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleStatusUpdate}
                disabled={!newStatus || !statusNote.trim()}
                className="flex-1 bg-yellow-600 text-white py-3 rounded-lg font-medium hover:bg-yellow-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Update Status
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
